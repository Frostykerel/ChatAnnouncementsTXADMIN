naamdump = {}

RegisterServerEvent('PixyTX:connect')
AddEventHandler('PixyTX:connect', function()
    namecache[tostring(source)] = GetPlayerName(source)
end)

AddEventHandler('txAdmin:events:playerBanned', function(eventData)
    local spelerid = eventData.author
    local reason = eventData.reason

    TriggerClientEvent('chat:addMessage', -1, {
        template = '<div class="bubble-message" style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(50, 52, 48, 0.6); border-radius: 6px;"><span style="color: rgb(232,0,0);">[Staff Panel]:</span> Er is <span style="color: rgb(240, 177, 50);"></span> iemand op vakantie gestuurd door <span style="color: rgb(153, 204, 0);">{0}</span> voor <span style="color: rgb(240, 177, 50);">{1}</span></div>',
        args = { spelerid, reason }
    })

end)

AddEventHandler('txAdmin:events:playerWarned', function(eventData)
    local targetname = namecache[tostring(eventData.target)]
    local admin = eventData.author
    local reason = eventData.reason

    TriggerClientEvent('chat:addMessage', -1, {
        template = '<div class="bubble-message" style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(28, 25, 25, 0.6); border-radius: 6px;"><span style="color: rgb(232,0,0);">[Staff Panel]: </span><span style="color: rgb(240, 177, 50);">{0}</span> has been warned by <span style="color: rgb(153, 204, 0);">{1}</span> for <span style="color: rgb(240, 177, 50);">{2}</span></div>',
        args = { targetname, admin, reason }
    })

end)

AddEventHandler('txAdmin:events:playerKicked', function(eventData)
    local spelerid = eventData.target
    local admin = eventData.author
    local reason = eventData.reason

    TriggerClientEvent('chat:addMessage', -1, {
        template = '<div class="bubble-message" style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(50, 52, 48, 0.6); border-radius: 6px;"><span style="color: rgb(232,0,0);">[Staff Panel]:</span> Player with ID <span style="color: rgb(240, 177, 50);">[{0}]</span> has been kicked by <span style="color: rgb(153, 204, 0);">{1}</span> for <span style="color: rgb(240, 177, 50);">{2}</span></div>',
        args = { spelerid, admin, reason }
    })

end)

AddEventHandler('txAdmin:events:scheduledRestart', function(eventData)
    if eventData.secondsRemaining == 1800 then
        CreateThread(function()
            Wait(1)
            TriggerClientEvent('chat:addMessage', -1, {
              template = '<div class="bubble-message" style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(255, 255, 0 0.6); border-radius: Console:<br> "De server gaat over 30 minuten restarten!"</div>',
              args = { target, author, reason }
            })
            ESX.SavePlayers(function()
            end)
        end)
    end
end)

AddEventHandler('txAdmin:events:announcement', function(eventData)
    local admin = eventData.author
    local reason = eventData.reason

    TriggerClientEvent('chat:addMessage', -1, {
        template = '<div class="bubble-message" style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(50, 52, 48, 0.6); border-radius: 11px;"><span style="color: rgb(232,0,0);">Console:</span> Player with ID <span style="color: rgb(240, 177, 50);">[{0}]</span> <span style="color: rgb(153, 204, 0);">{1}</span> for <span style="color: rgb(240, 177, 50);">{2}</span></div>',
        args = { admin, reason }
    })

end)