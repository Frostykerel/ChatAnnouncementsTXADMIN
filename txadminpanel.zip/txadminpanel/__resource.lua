client_scripts {
  'cl_sided.lua'
}

server_scripts {
  'sv_sided.lua'
}
